/*
╔══════════════════════════════════════════════╗
║       👑  𝑹𝑰𝑴𝑼𝑹𝑼 𝑴𝑫 〽️                        ║
╚══════════════════════════════════════════════╝

🪽 𝑵𝒐𝒕𝒆 :
Rimuru MD adalah SC hasil rename dari SC Ourin MD.

╭─────────────「 🜲 𝑰𝑵𝑭𝑶 𝑶𝑼𝑹𝑰𝑵 」─────────────╮
│ 👤 Developer : 𝑯𝒚𝒖𝒖 / 𝒁𝒂𝒏𝒏
│ 🎵 TikTok    : https://tiktok.com/@ourinmd
│ 📢 WhatsApp  : https://whatsapp.com/channel/0029VbB37bgBfxoAmAlsgE0t
╰─────────────────────────────────────────────╯

╭────────────「 ✦ 𝑰𝑵𝑭𝑶 𝑹𝑰𝑴𝑼𝑹𝑼 ✦ 」────────────╮
│ 👤 Developer Pihak Ketiga : 𝑨𝒏𝒊𝒕𝒂 𝑷𝒖𝒕𝒓𝒊 𝑨𝒛𝒛𝒂𝒉𝒓𝒂
│ 🎵 TikTok                 : https://tiktok.com/@anita.putri.azzah1
│ 📸 Instagram              : anit_aputriazzahrah
│ 📢 Saluran                : https://whatsapp.com/channel/0029Vb8dmsUElagkVPIw9X2P
│ ▶️ YouTube                : https://youtube.com/@rimurumd
╰─────────────────────────────────────────────╯

        ⚠️ 𝑫𝑶 𝑵𝑶𝑻 𝑹𝑬𝑴𝑶𝑽𝑬 𝑪𝑹𝑬𝑫𝑰𝑻 ⚠️
              ❖ 𝐉𝐚𝐧𝐠𝐚𝐧 𝐡𝐚𝐩𝐮𝐬 𝐜𝐫𝐞𝐝𝐢𝐭 ❖

                 「 👑 𝑹𝑰𝑴𝑼𝑹𝑼 𝑴𝑫 👑 」
*/

const pluginConfig = {
    name: 'coba',
    alias: ['try'],
    category: 'fun',
    description: 'Coba tanyakan sesuatu ke bot',
    usage: '.coba <pertanyaan>',
    example: '.coba tebak apa yang aku pikirkan',
    isOwner: false,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 3,
    energi: 0,
    isEnabled: true
};

const answers = [
    'Hmm, aku coba ya... Kamu lagi mikirin makanan!',
    'Aku tebak... Kamu lagi gabut!',
    'Coba ya... Kayaknya kamu lagi seneng!',
    'Hmm, aku rasa kamu lagi bingung.',
    'Aku coba nebak... Kamu lagi kangen seseorang?',
    'Kayaknya kamu lagi santai deh.',
    'Aku tebak kamu lagi scroll HP terus.',
    'Hmm, pasti lagi bosan ya?',
    'Coba ditebak... Kamu lagi pengen jalan-jalan!',
    'Aku rasa kamu lagi butuh hiburan.',
    'Hmm, kayaknya kamu lagi happy!',
    'Aku coba... Kamu pasti lagi penasaran!',
    'Tebakan aku: kamu lagi rebahan.',
    'Hmm, kamu mungkin lagi mikirin seseorang spesial.',
    'Aku coba: kamu lagi mau curhat?',
    'Kayaknya kamu lagi pengen main game!',
    'Hmm, aku tebak kamu lagi dengerin musik.',
    'Coba aku tebak... Kamu lagi di kamar!',
    'Aku rasa kamu lagi waiting for something.',
    'Hmm, tebakan aku: kamu butuh temen ngobrol!'
];

async function handler(m) {
    const text = m.text?.trim();
    
    if (!text) {
        return m.reply(`🎯 *ᴄᴏʙᴀ*\n\n> Masukkan sesuatu!\n\n*Contoh:*\n> .coba tebak apa yang aku pikirkan`);
    }
    
    const answer = answers[Math.floor(Math.random() * answers.length)];
    
    await m.reply(`${m.body.slice(1)}?
*${answer}*`);
}

export { pluginConfig as config, handler }