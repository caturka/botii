/*
╔══════════════════════════════════════════════╗
║       👑  𝑹𝑰𝑴𝑼𝑹𝑼 𝑴𝑫 〽️                        ║
╚══════════════════════════════════════════════╝

🪽 𝑵𝒐𝒕𝒆 :
Rimuru MD adalah SC hasil rename dari SC Ourin MD.

╭─────────────「 🜲 𝑰𝑵𝑭𝑶 𝑶𝑼𝑹𝑰𝑵 」─────────────╮
│ 👤 Developer : 𝑯𝒚𝒖𝒖 / 𝒁𝒂𝒏𝒏
│ 🎵 TikTok    : https://tiktok.com/@ourinmd
│ 📢 WhatsApp  : https://whatsapp.com/channel/0029VbB37bgBfxoAmAlsgE0t
╰─────────────────────────────────────────────╯

╭────────────「 ✦ 𝑰𝑵𝑭𝑶 𝑹𝑰𝑴𝑼𝑹𝑼 ✦ 」────────────╮
│ 👤 Developer Pihak Ketiga : 𝑨𝒏𝒊𝒕𝒂 𝑷𝒖𝒕𝒓𝒊 𝑨𝒛𝒛𝒂𝒉𝒓𝒂
│ 🎵 TikTok                 : https://tiktok.com/@anita.putri.azzah1
│ 📸 Instagram              : anit_aputriazzahrah
│ 📢 Saluran                : https://whatsapp.com/channel/0029Vb8dmsUElagkVPIw9X2P
│ ▶️ YouTube                : https://youtube.com/@rimurumd
╰─────────────────────────────────────────────╯

        ⚠️ 𝑫𝑶 𝑵𝑶𝑻 𝑹𝑬𝑴𝑶𝑽𝑬 𝑪𝑹𝑬𝑫𝑰𝑻 ⚠️
              ❖ 𝐉𝐚𝐧𝐠𝐚𝐧 𝐡𝐚𝐩𝐮𝐬 𝐜𝐫𝐞𝐝𝐢𝐭 ❖

                 「 👑 𝑹𝑰𝑴𝑼𝑹𝑼 𝑴𝑫 👑 」
*/

export const FEATURE_CREDIT = "Fitur By: Anita Putri Azzahra\nFitur SC Bot Rimuru MD 👑\nTiktok: https://tiktok.com/@anita.putri.azzah1\nSaluran Resmi: https://whatsapp.com/channel/0029Vb8dmsUElagkVPIw9X2P";


/*

# Fitur : Gatau
# Type : Plugins ESM
# Created by : https://whatsapp.com/channel/0029Vb2qri6JkK72MIrI8F1Z
# Api : Local Logic

   ⚠️ _Note_ ⚠️
jangan hapus wm ini banggg

*/

const pluginConfig = {
  name: "moveon",
  alias: [],
  category: "fun",
  description: "Imported from Rimuru MD V4.6",
  usage: "",
  example: "",
  isOwner: false,
  isPremium: false,
  isGroup: false,
  isPrivate: false,
  cooldown: 3,
  energi: 1,
  isEnabled: true,
};

async function handler(m, { sock }) {
    const conn = sock;
  const alasanGagal = [
    "*Error: Masih menyimpan fotonya di galeri*",
    "*Error: Masih suka stalking story-nya tiap malam*",
    "*Error: File hati sedang digunakan oleh proses lain: 'rindu.exe'*",
    "*Error: Gagal menghapus karena kenangan terlalu dalam*",
    "*Error: Sistem mendeteksi denyut jantung meningkat saat melihat namanya*",
    "*Error: Modul 'ikhlas.dll' belum terpasang*",
    "*Error: Masih berharap tanpa sadar*",
    "*Error: Masih ingat semua kata sandi dia*",
    "*Error: Proses move on terhenti, karena lagu 'Kenangan Manis.mp3' diputar kembali*",
    "*Error: Chat terakhir belum dihapus, masih dibaca berulang-ulang*"
  ]

  const teks = [
    "⏳ *Menjalankan perintah: moveon.exe*",
    "⌛ Mengakses direktori kenangan...",
    "⌛ Menemukan 1.042 file terkait: mantan.jpg, tawa.mp3, chat_kita.txt, pelukan terakhir.mp4",
    "⌛ Menghapus file: mantan.jpg",
    "⌛ Menghapus file: tawa.mp3",
    "⌛ Menghapus file: chat_kita.txt",
    "⌛ Menghapus file: pelukan terakhir.mp4",
    "⌛ Membersihkan folder: /hati/kenangan/spesial",
    "⌛ Menghapus log malam_nangis.log",
    "⌛ Menghapus config: harapan.yaml",
    "⌛ Menonaktifkan modul: berharap_lagi.dll",
    "⌛ Menutup port luka_terbuka 4040",
    "⌛ Mencabut izin akses memori emosional",
    "⌛ Restart sistem perasaan...",
    "⌛ Verifikasi status...",
    "❌ *Gagal*"
  ]

  for (let i = 0; i < teks.length; i++) {
    setTimeout(() => {
      conn.sendMessage(m.chat, { text: teks[i] }, { quoted: m })
    }, i * 1600)
  }

  
  setTimeout(() => {
    let alasan = alasanGagal[Math.floor(Math.random() * alasanGagal.length)]
    conn.sendMessage(m.chat, { text: alasan }, { quoted: m })
  }, teks.length * 1600)
}

export { pluginConfig as config, handler };
