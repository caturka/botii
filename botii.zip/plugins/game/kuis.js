/*
╔══════════════════════════════════════════════╗
║       👑  𝑹𝑰𝑴𝑼𝑹𝑼 𝑴𝑫 〽️                        ║
╚══════════════════════════════════════════════╝

🪽 𝑵𝒐𝒕𝒆 :
Rimuru MD adalah SC hasil rename dari SC Ourin MD.

╭─────────────「 🜲 𝑰𝑵𝑭𝑶 𝑶𝑼𝑹𝑰𝑵 」─────────────╮
│ 👤 Developer : 𝑯𝒚𝒖𝒖 / 𝒁𝒂𝒏𝒏
│ 🎵 TikTok    : https://tiktok.com/@ourinmd
│ 📢 WhatsApp  : https://whatsapp.com/channel/0029VbB37bgBfxoAmAlsgE0t
╰─────────────────────────────────────────────╯

╭────────────「 ✦ 𝑰𝑵𝑭𝑶 𝑹𝑰𝑴𝑼𝑹𝑼 ✦ 」────────────╮
│ 👤 Developer Pihak Ketiga : 𝑨𝒏𝒊𝒕𝒂 𝑷𝒖𝒕𝒓𝒊 𝑨𝒛𝒛𝒂𝒉𝒓𝒂
│ 🎵 TikTok                 : https://tiktok.com/@anita.putri.azzah1
│ 📸 Instagram              : anit_aputriazzahrah
│ 📢 Saluran                : https://whatsapp.com/channel/0029Vb8dmsUElagkVPIw9X2P
│ ▶️ YouTube                : https://youtube.com/@rimurumd
╰─────────────────────────────────────────────╯

        ⚠️ 𝑫𝑶 𝑵𝑶𝑻 𝑹𝑬𝑴𝑶𝑽𝑬 𝑪𝑹𝑬𝑫𝑰𝑻 ⚠️
              ❖ 𝐉𝐚𝐧𝐠𝐚𝐧 𝐡𝐚𝐩𝐮𝐬 𝐜𝐫𝐞𝐝𝐢𝐭 ❖

                 「 👑 𝑹𝑰𝑴𝑼𝑹𝑼 𝑴𝑫 👑 」
*/

export const FEATURE_CREDIT = "Fitur By: Anita Putri Azzahra\nFitur SC Bot Rimuru MD 👑\nTiktok: https://tiktok.com/@anita.putri.azzah1\nSaluran Resmi: https://whatsapp.com/channel/0029Vb8dmsUElagkVPIw9X2P";


import similarity from 'similarity'

const timeout = 30000
const reward = 5000

const pluginConfig = {
  name: "kuis",
  alias: [],
  category: "game",
  description: "Imported from Rimuru MD V4.6",
  usage: "",
  example: "",
  isOwner: false,
  isPremium: false,
  isGroup: false,
  isPrivate: false,
  cooldown: 3,
  energi: 1,
  isEnabled: true,
};

async function handler(m, { sock }) {
    const conn = sock;
  conn.kuis = conn.kuis ? conn.kuis : {}

  let id = m.chat
  if (id in conn.kuis)
    return m.reply('Masih ada soal belum terjawab di chat ini')

  let random = pickRandom(kuisData)
  let soal = random.soal
  let jawaban = random.jawaban.toLowerCase()

  let msg = await m.reply(`「 KUIS 」\n\n${soal}\n\n⏳ Waktu: 30 detik\n💎 Bonus: ${reward} XP\nKetik *nyerah* untuk menyerah`)

  conn.kuis[id] = [
    msg,
    { soal, jawaban },
    setTimeout(() => {
      if (conn.kuis[id]) {
        m.reply(`⏰ Waktu habis!\nJawaban: *${jawaban}*`)
        delete conn.kuis[id]
      }
    }, timeout)
  ]
}


handler.before = async function (m, { conn }) {
  conn.kuis = conn.kuis ? conn.kuis : {}
  let id = m.chat
  if (!(id in conn.kuis)) return

  if (!m.text) return

  let teks = m.text.toLowerCase().trim()
  let [msg, data, time] = conn.kuis[id]

  if (/^((me)?nyerah|surr?ender)$/i.test(teks)) {
    clearTimeout(time)
    m.reply(`🏳️ Menyerah!\nJawaban: *${data.jawaban}*`)
    delete conn.kuis[id]
    return true
  }

  if (similarity(teks, data.jawaban) >= 0.9) {
    clearTimeout(time)
    global.db.data.users[m.sender].exp += reward
    m.reply(`✅ Benar!\n+${reward} XP`)
    delete conn.kuis[id]
    return true
  }

  if (similarity(teks, data.jawaban) >= 0.7) {
    m.reply('🤏 Dikit lagi!')
    return true
  }

  return true
}

function pickRandom(list) {
  return list[Math.floor(Math.random() * list.length)]
}

const kuisData = [
  { soal: 'Pemain bola apa yang beratnya 3 kg?', jawaban: 'bola basket' },
  { soal: 'Kenapa di rel kereta api ditaruh batu?', jawaban: 'agar stabil' },
  { soal: 'Apa warna angin?', jawaban: 'tidak berwarna' },
  { soal: 'Mana yang lebih berat, kapas 100 kg atau besi 100 kg?', jawaban: 'sama' },
  { soal: 'Mengapa motor berhenti di lampu merah?', jawaban: 'karena lampu merah' },
  { soal: 'Kunci apa yang bisa bikin orang joget?', jawaban: 'kunci gitar' },
  { soal: 'Benda kecil apa yang bisa ngeluarin orang?', jawaban: 'peluru' },
  { soal: 'Malam apa yang paling mengerikan?', jawaban: 'malam minggu sendiri' },
  { soal: 'Ayam apa yang bikin sebel?', jawaban: 'ayam tetangga' },
  { soal: 'Kenapa di komputer ada tulisan enter?', jawaban: 'untuk masuk' },
  { soal: 'Apa persamaan uang dan rahasia?', jawaban: 'sama-sama sulit dijaga' },
  { soal: 'Apa bedanya kamu dan lukisan?', jawaban: 'lukisan diam kamu tidak' },
  { soal: 'Bis apa yang paling membahagiakan?', jawaban: 'bisa bersamamu' },
  { soal: 'Setan apa yang paling romantis?', jawaban: 'setan yang setia' },
  { soal: 'Kopi apa yang paling pahit?', jawaban: 'kopi kehidupan' },
  { soal: 'Rel apa yang paling sakit?', jawaban: 'rel hati' },
  { soal: 'Tiang apa yang enak?', jawaban: 'tiang listrik goreng' },
  { soal: 'Susu apa yang indah?', jawaban: 'susuah dilupakan' },
  { soal: 'Buah apa yang paling kaya?', jawaban: 'sawo matang' },
  { soal: 'Apa itu cemilan?', jawaban: 'cewe imut menawan' },
  { soal: 'Telur sama ayam duluan mana?', jawaban: 'telur' },
  { soal: 'Tentara apa yang paling kecil?', jawaban: 'tentara semut' },
  { soal: 'Lemari yang bisa masuk kantong?', jawaban: 'lemari es mini' },
  { soal: 'Bebek apa yang jalannya muter terus?', jawaban: 'bebek nyasar' },
  { soal: 'Ditutup jadi tongkat dibuka jadi tenda?', jawaban: 'payung' },
  { soal: 'Orang apa yang berenang tapi rambutnya tidak basah?', jawaban: 'orang botak' },
  { soal: 'Apa huruf kelima dalam abjad?', jawaban: 'e' },
  { soal: 'Pesawat jatuh kapal tenggelam munculnya dimana?', jawaban: 'di berita' },
  { soal: 'Apa yang ada di tengah sawah?', jawaban: 'w' },
]

export { pluginConfig as config, handler };
