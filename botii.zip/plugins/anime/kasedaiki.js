/*
╔══════════════════════════════════════════════╗
║       👑  𝑹𝑰𝑴𝑼𝑹𝑼 𝑴𝑫 〽️                        ║
╚══════════════════════════════════════════════╝

🪽 𝑵𝒐𝒕𝒆 :
Rimuru MD adalah SC hasil rename dari SC Ourin MD.

╭─────────────「 🜲 𝑰𝑵𝑭𝑶 𝑶𝑼𝑹𝑰𝑵 」─────────────╮
│ 👤 Developer : 𝑯𝒚𝒖𝒖 / 𝒁𝒂𝒏𝒏
│ 🎵 TikTok    : https://tiktok.com/@ourinmd
│ 📢 WhatsApp  : https://whatsapp.com/channel/0029VbB37bgBfxoAmAlsgE0t
╰─────────────────────────────────────────────╯

╭────────────「 ✦ 𝑰𝑵𝑭𝑶 𝑹𝑰𝑴𝑼𝑹𝑼 ✦ 」────────────╮
│ 👤 Developer Pihak Ketiga : 𝑨𝒏𝒊𝒕𝒂 𝑷𝒖𝒕𝒓𝒊 𝑨𝒛𝒛𝒂𝒉𝒓𝒂
│ 🎵 TikTok                 : https://tiktok.com/@anita.putri.azzah1
│ 📸 Instagram              : anit_aputriazzahrah
│ 📢 Saluran                : https://whatsapp.com/channel/0029Vb8dmsUElagkVPIw9X2P
│ ▶️ YouTube                : https://youtube.com/@rimurumd
╰─────────────────────────────────────────────╯

        ⚠️ 𝑫𝑶 𝑵𝑶𝑻 𝑹𝑬𝑴𝑶𝑽𝑬 𝑪𝑹𝑬𝑫𝑰𝑻 ⚠️
              ❖ 𝐉𝐚𝐧𝐠𝐚𝐧 𝐡𝐚𝐩𝐮𝐬 𝐜𝐫𝐞𝐝𝐢𝐭 ❖

                 「 👑 𝑹𝑰𝑴𝑼𝑹𝑼 𝑴𝑫 👑 」
*/

import axios from 'axios';
const pluginConfig = {
  name: "kasedaiki",
  alias: ["kasedai", "aiki"],
  category: "anime",
  description: "Kirim gambar random kasedaiki",
  usage: ".kasedaiki",
  example: ".kasedaiki",
  isOwner: false,
  isPremium: true,
  isGroup: false,
  isPrivate: false,
  cooldown: 5,
  energi: 1,
  isEnabled: true,
};

async function handler(m, { sock }) {
  await m.react("💞");

  try {
    const response = await axios.get("https://api.ourin.my.id/api/kasedaiki", {
      responseType: "arraybuffer",
      timeout: 30000,
      headers: {
        'User-Agent': 'Rimuru-Bot/2.0'
      }
    });

    const buffer = Buffer.from(response.data);

    await sock.sendMessage(m.chat, {
      image: buffer,
      caption: `💞 *ᴋᴀsᴇᴅᴀɪᴋɪ*\n\n> Random image dari api.ourin.my.id\n> Enjoy darling~ 💕`
    }, { quoted: m });

    await m.react("✅");
  } catch (err) {
    console.error('[Kasedaiki] Error:', err.message);
    await m.react("☢");
    await m.reply(`☢ *Error Darling!*\n\n> ${err.message}\n\nCoba lagi nanti ya~ 💕`);
  }
}

export { pluginConfig as config, handler };
