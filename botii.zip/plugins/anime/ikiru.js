/*
╔══════════════════════════════════════════════╗
║       👑  𝑹𝑰𝑴𝑼𝑹𝑼 𝑴𝑫 〽️                        ║
╚══════════════════════════════════════════════╝

🪽 𝑵𝒐𝒕𝒆 :
Rimuru MD adalah SC hasil rename dari SC Ourin MD.

╭─────────────「 🜲 𝑰𝑵𝑭𝑶 𝑶𝑼𝑹𝑰𝑵 」─────────────╮
│ 👤 Developer : 𝑯𝒚𝒖𝒖 / 𝒁𝒂𝒏𝒏
│ 🎵 TikTok    : https://tiktok.com/@ourinmd
│ 📢 WhatsApp  : https://whatsapp.com/channel/0029VbB37bgBfxoAmAlsgE0t
╰─────────────────────────────────────────────╯

╭────────────「 ✦ 𝑰𝑵𝑭𝑶 𝑹𝑰𝑴𝑼𝑹𝑼 ✦ 」────────────╮
│ 👤 Developer Pihak Ketiga : 𝑨𝒏𝒊𝒕𝒂 𝑷𝒖𝒕𝒓𝒊 𝑨𝒛𝒛𝒂𝒉𝒓𝒂
│ 🎵 TikTok                 : https://tiktok.com/@anita.putri.azzah1
│ 📸 Instagram              : anit_aputriazzahrah
│ 📢 Saluran                : https://whatsapp.com/channel/0029Vb8dmsUElagkVPIw9X2P
│ ▶️ YouTube                : https://youtube.com/@rimurumd
╰─────────────────────────────────────────────╯

        ⚠️ 𝑫𝑶 𝑵𝑶𝑻 𝑹𝑬𝑴𝑶𝑽𝑬 𝑪𝑹𝑬𝑫𝑰𝑻 ⚠️
              ❖ 𝐉𝐚𝐧𝐠𝐚𝐧 𝐡𝐚𝐩𝐮𝐬 𝐜𝐫𝐞𝐝𝐢𝐭 ❖

                 「 👑 𝑹𝑰𝑴𝑼𝑹𝑼 𝑴𝑫 👑 」
*/

export const FEATURE_CREDIT = "Fitur By: Anita Putri Azzahra\nFitur SC Bot Rimuru MD 👑\nTiktok: https://tiktok.com/@anita.putri.azzah1\nSaluran Resmi: https://whatsapp.com/channel/0029Vb8dmsUElagkVPIw9X2P";


import axios from "axios";
import * as cheerio from "cheerio";

const pluginConfig = {
  name: "ikiru",
  alias: [],
  category: "anime",
  description: "Imported from Rimuru MD V4.6",
  usage: "",
  example: "",
  isOwner: false,
  isPremium: false,
  isGroup: false,
  isPrivate: false,
  cooldown: 3,
  energi: 1,
  isEnabled: true,
};

async function handler(m, { text }) {
  if (!text)
    return m.reply("Contoh:\n.ikiru Solo Leveling");

  try {
    let html = null;

    /* =========================
       1. COBA SEARCH LANGSUNG
    ========================= */
    try {
      const res = await axios.post(
        "https://02.ikiru.wtf/wp-admin/admin-ajax.php",
        new URLSearchParams({
          action: "search",
          query: text
        }),
        {
          headers: {
            "Content-Type": "application/x-www-form-urlencoded",
            "HX-Request": "true",
            "HX-Target": "searchModalContent",
            "HX-Current-URL": "https://02.ikiru.wtf/",
            "User-Agent":
              "Mozilla/5.0 (Android 12; Mobile; rv:146.0) Gecko/146.0 Firefox/146.0",
            "Referer": "https://02.ikiru.wtf/"
          }
        }
      );

      html = res.data;
    } catch {
      html = null;
    }

    /* =========================
       2. FALLBACK: AMBIL NONCE
    ========================= */
    if (!html || !html.includes("<a")) {
      const home = await axios.get("https://02.ikiru.wtf/", {
        headers: {
          "User-Agent":
            "Mozilla/5.0 (Android 12; Mobile; rv:146.0) Gecko/146.0 Firefox/146.0"
        }
      });

      const nonce =
        home.data.match(/nonce["']?\s*:\s*["']([a-z0-9]+)["']/i)?.[1] ||
        home.data.match(/data-nonce=["']([a-z0-9]+)["']/i)?.[1];

      if (!nonce)
        return m.reply("❌ Gagal mengambil nonce Ikiru.");

      const res = await axios.post(
        "https://02.ikiru.wtf/wp-admin/admin-ajax.php",
        new URLSearchParams({
          nonce,
          action: "search",
          query: text
        }),
        {
          headers: {
            "Content-Type": "application/x-www-form-urlencoded",
            "HX-Request": "true",
            "HX-Target": "searchModalContent",
            "HX-Current-URL": "https://02.ikiru.wtf/",
            "User-Agent":
              "Mozilla/5.0 (Android 12; Mobile; rv:146.0) Gecko/146.0 Firefox/146.0",
            "Referer": "https://02.ikiru.wtf/"
          }
        }
      );

      html = res.data;
    }

    /* =========================
       3. PARSE RESULT
    ========================= */
    const $ = cheerio.load(html);
    const results = [];
    const seen = new Set();

    $("a:has(h4)").each((_, el) => {
      const link = $(el).attr("href");
      if (!link || seen.has(link)) return;

      const title = $(el).find("h4").first().text().trim();
      if (!title) return;

      let type = "";
      $(el)
        .find("span")
        .each((_, sp) => {
          const t = $(sp).text().trim();
          if (/^(Manhwa|Manga|Manhua)$/i.test(t)) {
            type = t;
            return false;
          }
        });

      let cover = null;
      $(el)
        .find("img")
        .each((_, img) => {
          const src =
            $(img).attr("data-src") ||
            $(img).attr("src");
          if (src && !src.includes("logo")) {
            cover = src;
            return false;
          }
        });

      seen.add(link);
      results.push({ title, link, type, cover });
    });

    if (!results.length)
      return m.reply("❌ Tidak ditemukan hasil.");

    /* =========================
       4. KIRIM LIST + COVER
    ========================= */
    let msg = `🔍 *Hasil Pencarian Ikiru*\n\n`;

    results.slice(0, 10).forEach((v, i) => {
      msg +=
        `*${i + 1}. ${v.title}*\n` +
        `${v.type ? v.type + "\n" : ""}` +
        `${v.link}\n\n`;
    });

    const cover = results[0]?.cover;

    if (cover) {
      await m.reply({
        image: { url: cover },
        caption: msg.trim()
      });
    } else {
      await m.reply(msg.trim());
    }

  } catch (e) {
    console.error(e);
    m.reply("❌ Gagal mengambil data dari Ikiru.");
  }
};

export { pluginConfig as config, handler };
