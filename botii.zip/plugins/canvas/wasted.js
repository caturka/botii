/*
╔══════════════════════════════════════════════╗
║       👑  𝑹𝑰𝑴𝑼𝑹𝑼 𝑴𝑫 〽️                        ║
╚══════════════════════════════════════════════╝

🪽 𝑵𝒐𝒕𝒆 :
Rimuru MD adalah SC hasil rename dari SC Ourin MD.

╭─────────────「 🜲 𝑰𝑵𝑭𝑶 𝑶𝑼𝑹𝑰𝑵 」─────────────╮
│ 👤 Developer : 𝑯𝒚𝒖𝒖 / 𝒁𝒂𝒏𝒏
│ 🎵 TikTok    : https://tiktok.com/@ourinmd
│ 📢 WhatsApp  : https://whatsapp.com/channel/0029VbB37bgBfxoAmAlsgE0t
╰─────────────────────────────────────────────╯

╭────────────「 ✦ 𝑰𝑵𝑭𝑶 𝑹𝑰𝑴𝑼𝑹𝑼 ✦ 」────────────╮
│ 👤 Developer Pihak Ketiga : 𝑨𝒏𝒊𝒕𝒂 𝑷𝒖𝒕𝒓𝒊 𝑨𝒛𝒛𝒂𝒉𝒓𝒂
│ 🎵 TikTok                 : https://tiktok.com/@anita.putri.azzah1
│ 📸 Instagram              : anit_aputriazzahrah
│ 📢 Saluran                : https://whatsapp.com/channel/0029Vb8dmsUElagkVPIw9X2P
│ ▶️ YouTube                : https://youtube.com/@rimurumd
╰─────────────────────────────────────────────╯

        ⚠️ 𝑫𝑶 𝑵𝑶𝑻 𝑹𝑬𝑴𝑶𝑽𝑬 𝑪𝑹𝑬𝑫𝑰𝑻 ⚠️
              ❖ 𝐉𝐚𝐧𝐠𝐚𝐧 𝐡𝐚𝐩𝐮𝐬 𝐜𝐫𝐞𝐝𝐢𝐭 ❖

                 「 👑 𝑹𝑰𝑴𝑼𝑹𝑼 𝑴𝑫 👑 」
*/

import axios from 'axios';
import FormData from 'form-data';
import config from '../../config.js';
const pluginConfig = {
    name: 'wasted',
    alias: ['gta', 'gtawasted'],
    category: 'maker',
    description: 'Efek wasted GTA pada foto',
    usage: '.wasted (reply foto)',
    example: '.wasted',
    isOwner: false,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 5,
    energi: 1,
    isEnabled: true
}

async function uploadToTmpFiles(buffer) {

    try {

        const form = new FormData()

        form.append('file', buffer, {
            filename: 'image.jpg',
            contentType: 'image/jpeg'
        })

        const response = await axios.post(
            'https://tmpfiles.org/api/v1/upload',
            form,
            {
                headers: form.getHeaders()
            }
        )

        return response.data.data.url
            .replace('tmpfiles.org/', 'tmpfiles.org/dl/')

    } catch (e) {

        console.log('Upload Error:', e)

        return null
    }
}

async function handler(m, { sock }) {

    try {

        let buffer = null

        // reply image
        if (
            m.quoted &&
            (
                m.quoted.mimetype?.includes('image') ||
                m.quoted.type === 'imageMessage'
            )
        ) {

            buffer = await m.quoted.download()

        }

        // direct image
        else if (
            m.mimetype?.includes('image')
        ) {

            buffer = await m.download()
        }

        if (!buffer) {

            return await m.reply(
                `❌ Reply / kirim gambar\n\nContoh:\n${pluginConfig.example}`
            )
        }

        const uploaded =
            await uploadToTmpFiles(buffer)

        if (!uploaded) {

            return await m.reply(
                '❌ Upload gambar gagal'
            )
        }

        // FIX API
        const api =
            `https://some-random-api.com/canvas/wasted?avatar=${encodeURIComponent(uploaded)}`

        const response = await axios.get(api, {
            responseType: 'arraybuffer'
        })

        const image = Buffer.from(response.data)

        await sock.sendMessage(
            m.chat,
            {
                image,
                caption: '💀 *WASTED EFFECT*'
            },
            { quoted: m }
        )

    } catch (error) {

        console.error('Wasted Error:', error)

        await m.reply(
            `❌ *GAGAL*\n\n> ${error.message}`
        )
    }
}

export { pluginConfig as config, handler };
