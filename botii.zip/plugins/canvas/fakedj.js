/*
╔══════════════════════════════════════════════╗
║       👑  𝑹𝑰𝑴𝑼𝑹𝑼 𝑴𝑫 〽️                        ║
╚══════════════════════════════════════════════╝

🪽 𝑵𝒐𝒕𝒆 :
Rimuru MD adalah SC hasil rename dari SC Ourin MD.

╭─────────────「 🜲 𝑰𝑵𝑭𝑶 𝑶𝑼𝑹𝑰𝑵 」─────────────╮
│ 👤 Developer : 𝑯𝒚𝒖𝒖 / 𝒁𝒂𝒏𝒏
│ 🎵 TikTok    : https://tiktok.com/@ourinmd
│ 📢 WhatsApp  : https://whatsapp.com/channel/0029VbB37bgBfxoAmAlsgE0t
╰─────────────────────────────────────────────╯

╭────────────「 ✦ 𝑰𝑵𝑭𝑶 𝑹𝑰𝑴𝑼𝑹𝑼 ✦ 」────────────╮
│ 👤 Developer Pihak Ketiga : 𝑨𝒏𝒊𝒕𝒂 𝑷𝒖𝒕𝒓𝒊 𝑨𝒛𝒛𝒂𝒉𝒓𝒂
│ 🎵 TikTok                 : https://tiktok.com/@anita.putri.azzah1
│ 📸 Instagram              : anit_aputriazzahrah
│ 📢 Saluran                : https://whatsapp.com/channel/0029Vb8dmsUElagkVPIw9X2P
│ ▶️ YouTube                : https://youtube.com/@rimurumd
╰─────────────────────────────────────────────╯

        ⚠️ 𝑫𝑶 𝑵𝑶𝑻 𝑹𝑬𝑴𝑶𝑽𝑬 𝑪𝑹𝑬𝑫𝑰𝑻 ⚠️
              ❖ 𝐉𝐚𝐧𝐠𝐚𝐧 𝐡𝐚𝐩𝐮𝐬 𝐜𝐫𝐞𝐝𝐢𝐭 ❖

                 「 👑 𝑹𝑰𝑴𝑼𝑹𝑼 𝑴𝑫 👑 」
*/

import axios from 'axios';

const pluginConfig = {
    name: 'fakedj',
    alias: ['djfake'],
    category: 'canvas',
    description: 'Membuat gambar fake DJ dari teks',
    usage: '.fakedj <teks>',
    example: '.fakedj nama pengirim',
    isOwner: false,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 10,
    energi: 1,
    isEnabled: true,
};

async function handler(m, { sock, text }) {
    const value = text?.trim();
    if (!value) return m.reply(`❌ Masukkan teks. Contoh: ${m.prefix}fakedj Anita`);
    await m.react('⏳');
    try {
        const apiUrl = `https://free-restapi.biz.id/api/fakedj?text=${encodeURIComponent(value)}`;
        const response = await axios.get(apiUrl, { responseType: 'arraybuffer', timeout: 60000 });
        await sock.sendMessage(m.chat, {
            image: Buffer.from(response.data),
            caption: `✅ Fake DJ\n📝 ${value}`,
        }, { quoted: m });
        await m.react('✅');
    } catch (error) {
        await m.react('❌').catch(() => {});
        return m.reply(`❌ Gagal membuat Fake DJ: ${error?.message || 'unknown error'}`);
    }
}

export { pluginConfig as config, handler };
