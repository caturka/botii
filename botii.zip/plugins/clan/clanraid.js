/*
╔══════════════════════════════════════════════╗
║       👑  𝑹𝑰𝑴𝑼𝑹𝑼 𝑴𝑫 〽️                        ║
╚══════════════════════════════════════════════╝

🪽 𝑵𝒐𝒕𝒆 :
Rimuru MD adalah SC hasil rename dari SC Ourin MD.

╭─────────────「 🜲 𝑰𝑵𝑭𝑶 𝑶𝑼𝑹𝑰𝑵 」─────────────╮
│ 👤 Developer : 𝑯𝒚𝒖𝒖 / 𝒁𝒂𝒏𝒏
│ 🎵 TikTok    : https://tiktok.com/@ourinmd
│ 📢 WhatsApp  : https://whatsapp.com/channel/0029VbB37bgBfxoAmAlsgE0t
╰─────────────────────────────────────────────╯

╭────────────「 ✦ 𝑰𝑵𝑭𝑶 𝑹𝑰𝑴𝑼𝑹𝑼 ✦ 」────────────╮
│ 👤 Developer Pihak Ketiga : 𝑨𝒏𝒊𝒕𝒂 𝑷𝒖𝒕𝒓𝒊 𝑨𝒛𝒛𝒂𝒉𝒓𝒂
│ 🎵 TikTok                 : https://tiktok.com/@anita.putri.azzah1
│ 📸 Instagram              : anit_aputriazzahrah
│ 📢 Saluran                : https://whatsapp.com/channel/0029Vb8dmsUElagkVPIw9X2P
│ ▶️ YouTube                : https://youtube.com/@rimurumd
╰─────────────────────────────────────────────╯

        ⚠️ 𝑫𝑶 𝑵𝑶𝑻 𝑹𝑬𝑴𝑶𝑽𝑬 𝑪𝑹𝑬𝑫𝑰𝑻 ⚠️
              ❖ 𝐉𝐚𝐧𝐠𝐚𝐧 𝐡𝐚𝐩𝐮𝐬 𝐜𝐫𝐞𝐝𝐢𝐭 ❖

                 「 👑 𝑹𝑰𝑴𝑼𝑹𝑼 𝑴𝑫 👑 」
*/

import { getDatabase } from '../../src/lib/rimuru-database.js';
const pluginConfig = {
    name: 'clanraid',
    alias: ['raid', 'clanevent'],
    category: 'clan',
    description: 'Mulai raid event clan',
    usage: '.clanraid',
    example: '.clanraid',
    isOwner: false,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 3600,
    energi: 10,
    isEnabled: true
}

const RAID_TYPES = {
    'goblin': { name: '👺 Goblin Invasion', duration: 30, reward: 5000, xp: 1000, targetKills: 50 },
    'skeleton': { name: '💀 Skeleton Army', duration: 45, reward: 10000, xp: 2000, targetKills: 100 },
    'demon': { name: '👹 Demon Horde', duration: 60, reward: 20000, xp: 4000, targetKills: 200 },
    'dragon': { name: '🐉 Dragon Flight', duration: 90, reward: 50000, xp: 10000, targetKills: 500 }
}

async function handler(m) {
    const db = getDatabase()
    const user = db.getUser(m.sender)
    
    if (!user.clanId) {
        return m.reply(`❌ Kamu belum punya clan!\n> Buat clan dengan *.clancreate*`)
    }
    
    const clan = db.db.data.clans[user.clanId]
    if (!clan) {
        return m.reply(`❌ Clan tidak ditemukan!`)
    }
    
    if (clan.leader !== m.sender && clan.roles?.[m.sender] !== 'coleader') {
        return m.reply(`❌ Hanya *Leader* atau *Co-Leader* yang bisa memulai raid!`)
    }
    
    if (clan.raid && clan.raid.active) {
        return m.reply(`⚠️ Raid sedang berlangsung!\n> Ketik *.clanraid* untuk join raid.`)
    }
    
    const clanLevel = clan.level || 1
    let availableRaids = Object.entries(RAID_TYPES)
    if (clanLevel < 5) availableRaids = availableRaids.filter(r => r[0] !== 'dragon')
    if (clanLevel < 3) availableRaids = availableRaids.filter(r => r[0] !== 'demon')
    
    const selectedRaid = availableRaids[Math.floor(Math.random() * availableRaids.length)][1]
    
    clan.raid = {
        active: true,
        type: selectedRaid.name,
        kills: 0,
        targetKills: selectedRaid.targetKills,
        startTime: Date.now(),
        endTime: Date.now() + (selectedRaid.duration * 1000),
        reward: selectedRaid.reward,
        xp: selectedRaid.xp,
        participants: [],
        contributions: {}
    }
    
    await db.save()
    
    let txt = `⚔️ *ᴄʟᴀɴ ʀᴀɪᴅ ꜱᴛᴀʀᴛᴇᴅ!*\n\n`
    txt += `╭┈┈⬡「 🎯 *ʀᴀɪᴅ ɪɴꜰᴏ* 」\n`
    txt += `┃ 🏷️ Type: *${selectedRaid.name}*\n`
    txt += `┃ ⏱️ Duration: *${selectedRaid.duration} menit*\n`
    txt += `┃ 🎯 Target kills: *${selectedRaid.targetKills}*\n`
    txt += `┃ 💰 Reward: *Rp ${selectedRaid.reward.toLocaleString('id-ID')}*\n`
    txt += `┃ 📈 XP: *+${selectedRaid.xp}*\n`
    txt += `╰┈┈┈┈┈┈┈┈⬡\n\n`
    txt += `> Ketik *.clanraid* untuk join dan kill monster!`
    
    await m.reply(txt)
}

export { pluginConfig as config, handler };
